import org.jsfml.graphics.Sprite;
import org.jsfml.system.Vector2f;

public class PhysicsBehaviour
{
    Vector2f velocity;



    public void move( Sprite sprite )
    {
        //sprite.setPosition( sprite.getPosition() + velocity );
    }

    public void update()
    {

    }
}
